"use client"

import { useState } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const slides = [
  {
    id: 1,
    title: "Switzerland",
    description: "X-Dev, Transforming code into visual poetry..!",
    image: "https://i.ibb.co/qCkd9jS/img1.jpg",
  },
  {
    id: 2,
    title: "Finland",
    description: "X-Dev, Transforming code into visual poetry..!",
    image: "https://i.ibb.co/jrRb11q/img2.jpg",
  },
  {
    id: 3,
    title: "Iceland",
    description: "X-Dev, Transforming code into visual poetry..!",
    image: "https://i.ibb.co/NSwVv8D/img3.jpg",
  },
  {
    id: 4,
    title: "Australia",
    description: "X-Dev, Transforming code into visual poetry..!",
    image: "https://i.ibb.co/Bq4Q0M8/img4.jpg",
  },
  {
    id: 5,
    title: "Netherland",
    description: "X-Dev, Transforming code into visual poetry..!",
    image: "https://i.ibb.co/jTQfmTq/img5.jpg",
  },
  {
    id: 6,
    title: "Ireland",
    description: "X-Dev, Transforming code into visual poetry..!",
    image: "https://i.ibb.co/RNkk6L0/img6.jpg",
  },
]

export default function LandingPage() {
  const [currentIndex, setCurrentIndex] = useState(0)

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % slides.length)
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + slides.length) % slides.length)
  }

  const getSlidePosition = (index: number) => {
    const position = (index - currentIndex + slides.length) % slides.length
    return position
  }

  return (
    <div className="min-h-screen bg-gray-400 flex items-center justify-center p-4">
      <div className="relative w-full max-w-7xl h-[650px] bg-gray-100 rounded-lg shadow-2xl overflow-hidden">
        <div className="relative w-full h-full">
          {slides.map((slide, index) => {
            const position = getSlidePosition(index)

            return (
              <div
                key={slide.id}
                className={`absolute transition-all duration-500 ease-in-out ${
                  position === 0
                    ? "top-0 left-0 w-full h-full rounded-none"
                    : position === 1
                      ? "top-0 left-0 w-full h-full rounded-none"
                      : position === 2
                        ? "top-1/2 left-1/2 w-48 h-72 -translate-y-1/2 rounded-3xl overflow-hidden shadow-2xl"
                        : position === 3
                          ? "top-1/2 left-1/2 w-48 h-72 -translate-y-1/2 translate-x-56 rounded-3xl overflow-hidden shadow-2xl"
                          : position === 4
                            ? "top-1/2 left-1/2 w-48 h-72 -translate-y-1/2 translate-x-[440px] rounded-3xl overflow-hidden shadow-2xl"
                            : "top-1/2 left-1/2 w-48 h-72 -translate-y-1/2 translate-x-[660px] rounded-3xl overflow-hidden shadow-2xl opacity-0"
                }`}
              >
                <div className="relative w-full h-full">
                  <Image
                    src={slide.image || "/placeholder.svg"}
                    alt={slide.title}
                    fill
                    className={`object-cover ${position > 1 ? "rounded-3xl" : ""}`}
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  />

                  {position === 1 && (
                    <div className="absolute top-1/2 left-24 w-80 -translate-y-1/2 text-white">
                      <h1 className="text-4xl font-bold uppercase mb-4 animate-in slide-in-from-bottom-8 duration-1000">
                        {slide.title}
                      </h1>
                      <p className="mb-6 text-lg animate-in slide-in-from-bottom-8 duration-1000 delay-300">
                        {slide.description}
                      </p>
                      <Button variant="secondary" className="animate-in slide-in-from-bottom-8 duration-1000 delay-600">
                        See More
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            )
          })}
        </div>

        {/* Navigation Buttons */}
        <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex gap-2">
          <Button
            variant="outline"
            size="icon"
            onClick={prevSlide}
            className="w-10 h-9 rounded-lg border-black hover:bg-gray-400 hover:text-white transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={nextSlide}
            className="w-10 h-9 rounded-lg border-black hover:bg-gray-400 hover:text-white transition-colors"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  )
}
