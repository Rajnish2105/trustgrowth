import LandingNavbar from "@/components/landingPage/landing-navbar";
import Footer from "@/components/footer";
import Link from "next/link";

export default function WebSolutions() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      <LandingNavbar />

      <section className="pt-32 pb-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="text-center mb-16">
            <h1 className="text-5xl font-bold text-gray-800 mb-6">
              Web{" "}
              <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                Solutions
              </span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Transform your business with our premium web development services.
              We create stunning, high-performance websites that drive results
              and enhance your digital presence.
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
            {[
              {
                title: "Custom Web Design",
                description:
                  "Unique, responsive designs tailored to your brand",
                icon: "🎨",
              },
              {
                title: "E-commerce Development",
                description:
                  "Powerful online stores that convert visitors to customers",
                icon: "🛒",
              },
              {
                title: "Mobile Optimization",
                description:
                  "Perfect performance across all devices and screen sizes",
                icon: "📱",
              },
              {
                title: "SEO Integration",
                description:
                  "Built-in optimization for better search engine rankings",
                icon: "🔍",
              },
              {
                title: "Performance Optimization",
                description:
                  "Lightning-fast loading speeds and smooth user experience",
                icon: "⚡",
              },
              {
                title: "Ongoing Support",
                description:
                  "24/7 maintenance and technical support for your website",
                icon: "🛠️",
              },
            ].map((service, index) => (
              <div
                key={index}
                className="bg-white/60 backdrop-blur-md border border-white/20 rounded-2xl p-8 hover:shadow-xl transition-all duration-300"
              >
                <div className="text-4xl mb-4">{service.icon}</div>
                <h3 className="text-xl font-semibold text-gray-800 mb-3">
                  {service.title}
                </h3>
                <p className="text-gray-600">{service.description}</p>
              </div>
            ))}
          </div>

          {/* CTA */}
          <div className="text-center">
            <Link
              href="/contact"
              className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
            >
              Request Your Project
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
